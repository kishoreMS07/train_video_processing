import cv2
import os
import numpy as np
from sklearn.cluster import KMeans

class FrameExtractor:
    def __init__(self, output_dir, num_frames=6):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self.num_frames = num_frames

    def extract_key_frames(self, video_processor, coach_info, coach_id, num_frames=None):
        if num_frames is None:
            num_frames = self.num_frames
        start = int(coach_info['start_frame'])
        end = int(coach_info['end_frame'])
        if end <= start:
            end = start + 1

        frame_indices = np.linspace(start, end, num_frames, dtype=int)
        frames = []
        saved_paths = []

    # ✅ Get base filename once
        video_base = os.path.splitext(os.path.basename(video_processor.video_path))[0]

    # ✅ Directory naming with filename prefix
        coach_dir = os.path.join(self.output_dir, f"{video_base}_coach_{coach_id:02d}")
        os.makedirs(coach_dir, exist_ok=True)

        for idx in frame_indices:   # <-- now idx is always defined inside loop
            f = video_processor.extract_frame(int(idx))
            if f is None:
                continue
            frames.append(f)

        # ✅ Prefixed filename
            path = os.path.join(
                coach_dir,
                f"{video_base}_coach_{coach_id:02d}_frame_{int(idx):06d}.jpg"
            )
            cv2.imwrite(path, f, [cv2.IMWRITE_JPEG_QUALITY, 90])
            saved_paths.append(path)

        return frames, frame_indices.tolist(), saved_paths


    def select_representative_frames(self, frames, num_representative=3):
        if not frames:
            return []
        if len(frames) <= num_representative:
            return list(range(len(frames)))

        feats = []
        for f in frames:
            hist = cv2.calcHist([f], [0,1,2], None, [4,4,4], [0,256,0,256,0,256])
            hist = cv2.normalize(hist, hist).flatten()
            gray = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY)
            sob = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
            texture = np.array([np.mean(np.abs(sob))])
            feats.append(np.concatenate([hist, texture]))

        feats = np.array(feats)
        n_clusters = min(num_representative, len(frames))
        kmeans = KMeans(n_clusters=n_clusters, random_state=0, n_init=10)
        labels = kmeans.fit_predict(feats)
        rep_indices = []
        for c in range(n_clusters):
            idxs = np.where(labels == c)[0]
            if len(idxs) == 0:
                continue
            center = kmeans.cluster_centers_[c]
            dists = np.linalg.norm(feats[idxs] - center, axis=1)
            rep_indices.append(int(idxs[np.argmin(dists)]))
        rep_indices = sorted(list(dict.fromkeys(rep_indices)))
        return rep_indices

    def analyze_coach_color_consistency(self, frames):

        if len(frames) < 2:
            return True, 0.0
        lab_frames = [cv2.cvtColor(f, cv2.COLOR_BGR2LAB) for f in frames]
        avg_colors = [np.mean(f.reshape(-1,3), axis=0) for f in lab_frames]
        diffs = [np.linalg.norm(avg_colors[i] - avg_colors[i+1]) for i in range(len(avg_colors)-1)]
        max_diff = float(max(diffs) if len(diffs) else 0.0)
        is_consistent = max_diff < 20.0
        return is_consistent, max_diff
