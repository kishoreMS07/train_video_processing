# video_processor.py
import cv2
import os

class VideoProcessor:
    def __init__(self, video_path):
        if not os.path.exists(video_path):
            raise FileNotFoundError(f"Video not found: {video_path}")
        self.video_path = video_path
        self.cap = cv2.VideoCapture(video_path)
        if not self.cap.isOpened():
            raise IOError(f"Cannot open video: {video_path}")

        self.fps = float(self.cap.get(cv2.CAP_PROP_FPS) or 25.0)
        self.total_frames = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 640)
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 360)
        self.resolution = (self.width, self.height)

    def get_video_info(self):
        duration = self.total_frames / self.fps if self.fps else 0.0
        return {
            "fps": self.fps,
            "total_frames": self.total_frames,
            "resolution": self.resolution,
            "duration": duration
        }

    def extract_frame(self, frame_index, resize_to=None):
        if frame_index < 0:
            frame_index = 0
        if frame_index >= self.total_frames:
            frame_index = self.total_frames - 1

        self.cap.set(cv2.CAP_PROP_POS_FRAMES, frame_index)
        ok, frame = self.cap.read()
        if not ok or frame is None:
            return None
        if resize_to:
            frame = cv2.resize(frame, resize_to)
        return frame

    def save_segment(self, start_frame, end_frame, out_path, fourcc_str='mp4v'):
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        start_frame = max(0, int(start_frame))
        end_frame = int(min(end_frame, self.total_frames - 1))
        if end_frame <= start_frame:
            end_frame = start_frame + 1

        fourcc = cv2.VideoWriter_fourcc(*fourcc_str)
        writer = cv2.VideoWriter(out_path, fourcc, self.fps, self.resolution)
        if not writer.isOpened():
            raise IOError(f"Cannot open VideoWriter for {out_path}")

        self.cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
        current = start_frame
        while current <= end_frame:
            ok, frame = self.cap.read()
            if not ok or frame is None:
                break
            if (frame.shape[1], frame.shape[0]) != self.resolution:
                frame = cv2.resize(frame, self.resolution)
            writer.write(frame)
            current += 1

        writer.release()
        return out_path

    def release(self):
        try:
            self.cap.release()
        except:
            pass
