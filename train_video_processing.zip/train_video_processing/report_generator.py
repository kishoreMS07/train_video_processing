from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, cm
from reportlab.lib import colors
import os

class ReportGenerator:
    def __init__(self, output_path):
        self.output_path = output_path
        self.doc = SimpleDocTemplate(output_path, pagesize=A4)
        self.styles = getSampleStyleSheet()
        self.story = []

    def add_title(self, text):
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            spaceAfter=30,
            alignment=1
        )
        self.story.append(Paragraph(text, title_style))
        self.story.append(Spacer(1, 0.2*inch))

    def add_heading(self, text, level=2):
        if level == 2:
            self.story.append(Paragraph(text, self.styles['Heading2']))
        else:
            self.story.append(Paragraph(text, self.styles['Heading3']))
        self.story.append(Spacer(1, 0.1*inch))

    def add_paragraph(self, text):
        self.story.append(Paragraph(text, self.styles['BodyText']))
        self.story.append(Spacer(1, 0.1*inch))

    def add_image(self, image_path, width=4*inch, height=3*inch):
        if os.path.exists(image_path):
            try:
                img = Image(image_path, width=width, height=height)
                self.story.append(img)
                self.story.append(Spacer(1, 0.1*inch))
            except:
                self.add_paragraph(f"Image not available: {os.path.basename(image_path)}")

    def add_page_break(self):
        self.story.append(PageBreak())

    def add_table(self, data, col_widths=None):
        table = Table(data, colWidths=col_widths)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#003366')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#F0F0F0')),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        self.story.append(table)
        self.story.append(Spacer(1, 0.2*inch))

    def generate_report(self, video_info, coaches, frame_data, coach_analysis):
        # Title page
        self.add_title("TRAIN COACH ANALYSIS REPORT")
        self.add_paragraph(f"<b>Report Generated:</b> {video_info.get('timestamp', '')}")
        self.add_paragraph(f"<b>Video File:</b> {video_info.get('filename', '')}")
        self.add_paragraph(f"<b>Duration:</b> {video_info.get('duration', 0):.2f} seconds")
        self.add_paragraph(f"<b>Resolution:</b> {video_info.get('resolution', (0,0))[0]}x{video_info.get('resolution', (0,0))[1]}")
        self.add_paragraph(f"<b>Frame Rate:</b> {video_info.get('fps', 0):.2f} fps")
        self.add_paragraph(f"<b>Total Frames:</b> {video_info.get('total_frames', 0)}")

        self.add_page_break()
        self.add_heading("EXECUTIVE SUMMARY", 2)

        engine_count = sum(1 for ca in coach_analysis.values() if 'engine' in ca.get('type', ''))
        wagon_count = sum(1 for ca in coach_analysis.values() if ca.get('type') == 'wagon')
        open_doors_count = sum(1 for ca in coach_analysis.values() if ca.get('door_status') == 'open')

        summary_data = [
            ['Metric', 'Value'],
            ['Total Coaches Detected', str(len(coaches))],
            ['Engines', str(engine_count)],
            ['Wagons', str(wagon_count)],
            ['Coaches with Open Doors', str(open_doors_count)],
            ['Video Duration', f"{video_info.get('duration',0):.2f} seconds"],
            ['Analysis Date', video_info.get('timestamp','')]
        ]
        self.add_table(summary_data, col_widths=[3*inch, 3*inch])

        self.add_heading("DETAILED COACH SUMMARY", 2)
        coach_summary_data = [['Coach ID', 'Type', 'Duration (s)', 'Door Status', 'Color Consistent']]
        for coach_id, analysis in coach_analysis.items():
            coach_summary_data.append([
                f"Coach {coach_id}",
                analysis.get('type', 'unknown'),
                f"{analysis.get('duration', 0):.2f}",
                analysis.get('door_status', 'unknown'),
                "Yes" if analysis.get('color_consistent', False) else "No"
            ])
        self.add_table(coach_summary_data)
        self.add_page_break()

        for coach_id, analysis in coach_analysis.items():
            self.add_heading(f"COACH {coach_id} ANALYSIS - {analysis.get('type','unknown').upper()}", 3)
            meta_data = [
                ['Parameter', 'Value'],
                ['Type', analysis.get('type', 'unknown')],
                ['Door Status', analysis.get('door_status', 'unknown')],
                ['Duration', f"{analysis.get('duration', 0):.2f} seconds"],
                ['Frame Range', f"{analysis.get('start_frame', 0)} - {analysis.get('end_frame', 0)}"],
                ['Color Consistency', "Consistent" if analysis.get('color_consistent', False) else "Inconsistent"],
                ['Maximum Color Difference', f"{analysis.get('max_color_diff', 0):.2f}"],
                ['Video Available', "Yes" if analysis.get('video_path') else "No"]
            ]
            self.add_table(meta_data, col_widths=[2*inch, 3*inch])

            self.add_heading("Representative Frames", 4)
            coach_frames = frame_data.get(coach_id, [])
            for i, frame_path in enumerate(coach_frames):
                if i % 2 == 0 and i > 0:
                    self.add_page_break()
                self.add_image(frame_path, width=4*inch, height=3*inch)
            self.add_page_break()

        self.doc.build(self.story)
