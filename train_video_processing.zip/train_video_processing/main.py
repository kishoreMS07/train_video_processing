import os
import argparse
from datetime import datetime
import cv2
import numpy as np

from video_processor import VideoProcessor
from coach_detector import CoachDetector
from frame_extractor import FrameExtractor
from door_detector import DoorDetector
from report_generator import ReportGenerator
from utils import save_json, save_csv_events

def classify_coach_roles(coaches_report):

    total = len(coaches_report)
    for i, cid in enumerate(sorted(coaches_report.keys()), start=1):
        if i == 1:
            role = 'front_engine'
        elif i == total:
            role = 'rear_engine'
        else:
            role = 'wagon'
        coaches_report[cid]['type'] = role
    return {cid: coaches_report[cid]['type'] for cid in coaches_report.keys()}

def create_overall_annotated_video(vp, coaches_report, output_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    fps = vp.fps
    W, H = vp.width, vp.height
    writer = cv2.VideoWriter(output_path, fourcc, fps, (W, H))
    if not writer.isOpened():
        print("Warning: cannot create overall annotated video at", output_path)
        return None

    # create segments list: (start, end, coach_id)
    segments = []
    for cid, meta in coaches_report.items():
        segments.append((meta['start_frame'], meta['end_frame'], cid))
    segments.sort(key=lambda x: x[0])

    dd = DoorDetector()  # used only for annotate_frame

    total_frames = vp.total_frames
    print("Writing overall annotated video...")
    for fi in range(total_frames):
        frame = vp.extract_frame(fi)
        if frame is None:
            frame = np.zeros((H, W, 3), dtype=np.uint8)

        # find coach for this frame
        coach_id = None
        start_frame = 0
        for s, e, cid in segments:
            if fi >= s and fi <= e:
                coach_id = cid
                start_frame = s
                break

        if coach_id is not None:
            meta = coaches_report.get(coach_id, {})
            per_frame_states = meta.get('per_frame_states', [])
            offset = fi - start_frame
            latest_states = None
            if 0 <= offset < len(per_frame_states):
                latest_states = per_frame_states[offset]
            bbox = meta.get('bbox', (0,0,vp.width, vp.height))
            annotated = dd.annotate_frame(frame, bbox, latest_states)
            role = meta.get('type', 'unknown')
            text = f"Coach-{coach_id} ({role})"
            cv2.putText(annotated, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)
            writer.write(annotated)
        else:
            writer.write(frame)

    writer.release()
    print("Overall annotated video saved to:", output_path)
    return output_path

def process_video(input_video_path, output_base_dir, annotated_overall=True):
    os.makedirs(output_base_dir, exist_ok=True)
    processed_videos_dir = os.path.join(output_base_dir, "processed_videos")
    extracted_frames_dir = os.path.join(output_base_dir, "extracted_frames")
    reports_dir = os.path.join(output_base_dir, "reports")
    os.makedirs(processed_videos_dir, exist_ok=True)
    os.makedirs(extracted_frames_dir, exist_ok=True)
    os.makedirs(reports_dir, exist_ok=True)

    vp = VideoProcessor(input_video_path)
    info = vp.get_video_info()
    info['filename'] = os.path.basename(input_video_path)
    info['timestamp'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    print(f"Video: {info['filename']} duration {info['duration']:.2f}s fps {info['fps']:.2f} frames {info['total_frames']}")

    detector = CoachDetector(sample_seconds=0.3, min_duration=1.2, max_duration=20.0)
    segments = detector.detect_coaches(vp)

    # fallback splitting if detection failed
    if len(segments) < 2:
        total_duration = info['duration']
        est = max(1.2, min(5.0, total_duration / max(1, int(total_duration / 4.0))))
        approx_count = max(1, int(total_duration / est))
        frames_per = max(1, int(vp.total_frames / approx_count))
        segments = []
        for i in range(approx_count):
            s = i * frames_per
            e = min((i + 1) * frames_per - 1, vp.total_frames - 1)
            segments.append({'start_frame': int(s), 'end_frame': int(e), 'duration': (e - s) / vp.fps})

    print(f"Final coach segments count: {len(segments)}")

    extractor = FrameExtractor(extracted_frames_dir, num_frames=6)

    # ✅ FIX: changed num_rois -> num_doors
    door_detector = DoorDetector(
        vertical_frac=(0.25, 0.75),
        edge_threshold_low=50,
        edge_threshold_high=150,
        motion_change_threshold=0.1,
        min_area_fraction=0.05
    )


    coaches_report = {}
    events_by_coach = {}

    for idx, seg in enumerate(segments):
        coach_id = idx + 1
        s = seg['start_frame']
        e = seg['end_frame']
        dur = seg.get('duration', (e - s) / vp.fps)
        print(f"Processing coach {coach_id}: frames [{s}-{e}] dur {dur:.2f}s")

        video_base = os.path.splitext(os.path.basename(input_video_path))[0]
        coach_dir = os.path.join(processed_videos_dir, f"{video_base}_coach_{coach_id:02d}")
        os.makedirs(coach_dir, exist_ok=True)
        coach_video_path = os.path.join(coach_dir, f"{video_base}_coach_{coach_id:02d}.mp4")


        # save coach video
        try:
            vp.save_segment(s, e, coach_video_path, fourcc_str='mp4v')
        except Exception as ex:
            print(f"Warning: failed to save coach segment {coach_id}: {ex}")
            coach_video_path = None

        # safe bounding box (central area)
        sample_frame = vp.extract_frame(max(s, 0))
        if sample_frame is not None:
            h, w = sample_frame.shape[:2]
            bbox = (int(w*0.05), int(h*0.05), int(w*0.90), int(h*0.90))
        else:
            bbox = (0, 0, vp.width, vp.height)

        # door detection (returns events, per-frame states, summary)
        events, per_frame_states, door_summary = door_detector.analyze_segment(vp, s, e, bbox)
        events_by_coach[coach_id] = events

        # counts
        open_events_total = sum(door_summary.get('per_roi_open_events', []))
        close_events_total = sum(door_summary.get('per_roi_close_events', []))
        door_status = door_summary.get('overall_status', 'unknown')

        # representative frames + color consistency
        frames_saved, frame_idx_list, saved_paths = extractor.extract_key_frames(vp, seg, coach_id, num_frames=6)
        color_consistent, max_color_diff = extractor.analyze_coach_color_consistency(frames_saved)

        # annotated per-coach video (full segment)
        ann_path = os.path.join(coach_dir, f"coach_{coach_id:02d}_door_annotated.mp4")
        try:
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            writer = cv2.VideoWriter(ann_path, fourcc, vp.fps, (vp.width, vp.height))
            if writer.isOpened():
                for offset, frame_idx in enumerate(range(s, e+1)):
                    fr = vp.extract_frame(frame_idx)
                    if fr is None:
                        fr = np.zeros((vp.height, vp.width, 3), dtype=np.uint8)
                    latest_states = per_frame_states[offset] if offset < len(per_frame_states) else None
                    annotated = door_detector.annotate_frame(fr, bbox, latest_states)
                    cv2.putText(annotated, f"Coach-{coach_id} OpenEv:{open_events_total} CloseEv:{close_events_total} Status:{door_status}",
                                (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
                    writer.write(annotated)
                writer.release()
            else:
                ann_path = None
        except Exception as ex:
            print("Annotated per-coach video generation failed:", ex)
            ann_path = None

        coaches_report[coach_id] = {
            'coach_id': coach_id,
            'start_frame': int(s),
            'end_frame': int(e),
            'duration': float(dur),
            'video_path': coach_video_path,
            'annotated_video': ann_path if ann_path and os.path.exists(ann_path) else None,
            'representative_frames': saved_paths,
            'open_events': int(open_events_total),
            'close_events': int(close_events_total),
            'door_status': door_status,
            'per_frame_states': per_frame_states,
            'bbox': bbox,
            'color_consistent': bool(color_consistent),
            'max_color_diff': float(max_color_diff),
            # include raw door summary for debugging/analysis
            'door_summary': door_summary
        }

    # roles + type injection
    roles = classify_coach_roles(coaches_report)
    engine_ids = [cid for cid, role in roles.items() if 'engine' in role]
    wagon_count = sum(1 for role in roles.values() if role == 'wagon')
    end_cart_count = sum(1 for role in roles.values() if 'rear_engine' in role)

    report = {
        'input_video': info['filename'],
        'timestamp': info['timestamp'],
        'fps': info['fps'],
        'total_frames': info.get('total_frames', 0),
        'detected_coaches': len(segments),
        'engine_count': len([r for r in roles.values() if 'engine' in r]),
        'wagon_count': wagon_count,
        'end_cart_count': end_cart_count,
        'engine_ids': engine_ids,
        'roles': roles,
        'coaches': coaches_report,
        'events_by_coach': events_by_coach
    }

    json_path = os.path.join(reports_dir, f"report_{os.path.splitext(info['filename'])[0]}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
    save_json(report, json_path)
    csv_path = os.path.join(reports_dir, f"events_{os.path.splitext(info['filename'])[0]}.csv")
    save_csv_events(csv_path, events_by_coach)

    if annotated_overall:
        overall_path = os.path.join(processed_videos_dir, "annotated_overall.mp4")
        try:
            create_overall_annotated_video(vp, coaches_report, overall_path)
        except Exception as ex:
            print("Failed creating overall annotated video:", ex)

    # generate PDF (non-fatal)
    try:
        pdf_name = f"report_{os.path.splitext(info['filename'])[0]}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        pdf_path = os.path.join(reports_dir, pdf_name)
        rg = ReportGenerator(pdf_path)
        rg.generate_report(info, list(range(1, len(segments)+1)), {k: v['representative_frames'] for k,v in coaches_report.items()}, coaches_report)
        print("PDF report generated:", pdf_path)
    except Exception as ex:
        print("PDF generation failed (optional):", ex)

    print("JSON report:", json_path)
    print("CSV events:", csv_path)
    vp.release()
    return json_path

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("input_video", help="path to input video")
    parser.add_argument("--output_dir", default="output")
    parser.add_argument("--no_overall", action="store_true", help="disable overall annotated video creation")
    args = parser.parse_args()
    process_video(args.input_video, args.output_dir, annotated_overall=(not args.no_overall))
