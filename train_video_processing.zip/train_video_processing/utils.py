# utils.py
import json
import csv
import os

def save_json(data, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

def save_csv_events(path, events_by_coach):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    rows = []
    for coach_id, evs in events_by_coach.items():
        for e in evs:
            rows.append([coach_id, e.get('frame_global', -1), e.get('state'), e.get('roi_index'), e.get('confidence', e.get('motion_frac', 0.0)), e.get('motion_pixels', 0)])
    with open(path, "w", newline='') as f:
        w = csv.writer(f)
        w.writerow(['coach_id', 'frame_global', 'state', 'roi_index', 'confidence_or_motion_frac', 'motion_pixels'])
        w.writerows(rows)
