# coach_detector.py
import cv2
import numpy as np
from scipy.ndimage import gaussian_filter1d

class CoachDetector:

    def __init__(self, sample_seconds=0.3, min_duration=1.5, max_duration=20.0, gaussian_sigma=1.0):
        self.sample_seconds = sample_seconds
        self.min_duration = min_duration
        self.max_duration = max_duration
        self.gaussian_sigma = gaussian_sigma

    def detect_coaches(self, video_processor):
        fps = video_processor.fps
        total_frames = video_processor.total_frames
        if total_frames <= 0 or fps <= 0:
            return []

        sample_interval = max(1, int(round(fps * self.sample_seconds)))
        sample_indices = list(range(0, total_frames, sample_interval))
        if sample_indices[-1] != (total_frames - 1):
            sample_indices.append(total_frames - 1)

        frames_gray = []
        for idx in sample_indices:
            f = video_processor.extract_frame(idx, resize_to=(640, 360))
            if f is None:
                continue
            gray = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY)
            frames_gray.append((idx, gray))

        if len(frames_gray) < 2:
            return [{
                'start_frame': 0,
                'end_frame': total_frames - 1,
                'duration': total_frames / fps
            }]

        diffs = []
        indices = []
        prev = frames_gray[0][1]
        indices.append(frames_gray[0][0])
        diffs.append(0.0)
        for idx, g in frames_gray[1:]:
            diff = cv2.absdiff(prev, g)
            diffs.append(float(np.mean(diff)))
            indices.append(idx)
            prev = g

        diffs_arr = np.array(diffs, dtype=float)
        smoothed = gaussian_filter1d(diffs_arr, sigma=self.gaussian_sigma)

        mean = float(smoothed.mean())
        std = float(smoothed.std()) if smoothed.std() > 1e-6 else 1.0
        k = 0.8
        thr = mean + k * std

        high = smoothed > thr

        boundaries = []
        start = None
        for i, val in enumerate(high):
            if val and start is None:
                start = i
            elif (not val) and (start is not None):
                end = i - 1
                mid = (start + end) // 2
                boundaries.append(indices[mid])
                start = None
        if start is not None:
            mid = (start + len(high) - 1) // 2
            boundaries.append(indices[mid])

        if not boundaries:
            return [{
                'start_frame': 0,
                'end_frame': total_frames - 1,
                'duration': total_frames / fps
            }]

        boundaries = sorted(set([0] + boundaries + [total_frames - 1]))

        segments = []
        for i in range(len(boundaries) - 1):
            s = int(boundaries[i])
            e = int(boundaries[i + 1])
            duration = (e - s) / fps
            if duration < self.min_duration:
                if segments:
                    prev_seg = segments[-1]
                    prev_seg['end_frame'] = e
                    prev_seg['duration'] = (prev_seg['end_frame'] - prev_seg['start_frame']) / fps
                else:
                    segments.append({'start_frame': s, 'end_frame': e, 'duration': duration})
                continue

            if duration > self.max_duration:
                parts = int(np.ceil(duration / self.max_duration))
                frames_per_part = int(np.ceil((e - s + 1) / parts))
                for p in range(parts):
                    ps = s + p * frames_per_part
                    pe = min(s + (p + 1) * frames_per_part - 1, e)
                    seg_dur = (pe - ps) / fps
                    if seg_dur >= self.min_duration:
                        segments.append({'start_frame': int(ps), 'end_frame': int(pe), 'duration': seg_dur})
            else:
                segments.append({'start_frame': s, 'end_frame': e, 'duration': duration})

        if len(segments) < 2:
            total_duration = total_frames / fps
            est_duration = max(self.min_duration, min(5.0, total_duration / max(1, int(total_duration / 4.0))))
            approx_count = max(1, int(total_duration / est_duration))
            frames_per = max(1, int(np.ceil(total_frames / approx_count)))
            segments = []
            for i in range(approx_count):
                s = i * frames_per
                e = min((i + 1) * frames_per - 1, total_frames - 1)
                segments.append({'start_frame': int(s), 'end_frame': int(e), 'duration': (e - s) / fps})

        return segments
