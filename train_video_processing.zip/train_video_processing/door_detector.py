import cv2
import numpy as np

class DoorDetector:
    def __init__(self, vertical_frac=(0.25, 0.75),
                 edge_threshold_low=50,
                 edge_threshold_high=150,
                 motion_change_threshold=0.1,
                 min_area_fraction=0.05):

        self.vertical_frac = vertical_frac
        self.edge_threshold_low = edge_threshold_low
        self.edge_threshold_high = edge_threshold_high
        self.motion_change_threshold = motion_change_threshold
        self.min_area_fraction = min_area_fraction


    def analyze_segment(self, vp, start_frame, end_frame, bbox):

        events = []
        per_frame_states = []

        x1, y1, x2, y2 = bbox
        dy1 = int(y1 + (y2 - y1) * self.vertical_frac[0])
        dy2 = int(y1 + (y2 - y1) * self.vertical_frac[1])

        prev_edges = None
        open_count = 0
        close_count = 0

        for fi in range(start_frame, end_frame + 1):
            frame = vp.extract_frame(fi)
            if frame is None:
                state = "unknown"
                per_frame_states.append(state)
                events.append({'frame_global': fi, 'state': state, 'roi_index':0, 'confidence':0, 'motion_pixels':0})
                continue

            roi = frame[dy1:dy2, x1:x2]
            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
            gray = cv2.GaussianBlur(gray, (5,5), 0)
            edges = cv2.Canny(gray, self.edge_threshold_low, self.edge_threshold_high)

            # Fraction of edge pixels
            edge_fraction = np.sum(edges>0) / edges.size

            # Compare with previous frame
            if prev_edges is not None:
                diff = cv2.absdiff(edges, prev_edges)
                change_frac = np.sum(diff>0)/edges.size
            else:
                change_frac = 0.0

            # Determine state
            if change_frac > self.motion_change_threshold:
                state = "open"
                open_count += 1
            else:
                state = "closed"
                close_count += 1

            per_frame_states.append(state)
            events.append({
                'frame_global': fi,
                'state': state,
                'roi_index': 0,
                'confidence': change_frac,
                'motion_pixels': int(change_frac*edges.size)
            })

            prev_edges = edges

        summary = {
            "per_roi_open_events": [open_count],
            "per_roi_close_events": [close_count],
            "overall_status": per_frame_states[-1] if per_frame_states else "unknown"
        }

        return events, per_frame_states, summary

    def annotate_frame(self, frame, bbox, per_frame_state=None):
        annotated = frame.copy()
        x1, y1, x2, y2 = bbox
        color = (0,255,0) if per_frame_state=="open" else (0,0,255)
        cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
        if per_frame_state:
            cv2.putText(annotated, f"Door:{per_frame_state}", (x1, y1-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        return annotated
